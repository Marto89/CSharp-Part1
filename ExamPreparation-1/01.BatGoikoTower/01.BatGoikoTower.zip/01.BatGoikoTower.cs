﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.BatGoikoTower
{
    class Program
    {
        static void Main()
        {
            int height = int.Parse(Console.ReadLine());
            char point='.';
            char slash = '/';
            char backslash = '\\';
            char dash = '-';

            for (int i = 0; i <height; i++)
            {
                Console.Write(new string(point,height-i-1));
                Console.Write(slash);
                if (i == 1 || i == 3 || i == 6 || i == 10 || i == 15 || i == 21 || i == 28 || i == 36)
                {
                    Console.Write(new string(dash, i * 2));
                }
                else
                {
                    Console.Write(new string(point,i*2));
                }
                Console.Write(backslash);
                Console.WriteLine(new string(point, height - i - 1));
            }
        }
    }
}
